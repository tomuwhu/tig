from browser import document, html
document <= html.H1("Hatványozás")
for i in range(1,10):
    document <= html.DIV(f"{i} négyzete: {i ** 2}")
    print(i, i ** 2)