from browser import document as D, html as H
div = lambda x, i: H.DIV(x, Class=i)
for i in range(15):
    D <= div(f"cica {i} {i ** 2}", f"x x{i}")
