from browser import document as D, html as H
D <= H.H1("Hello World!")